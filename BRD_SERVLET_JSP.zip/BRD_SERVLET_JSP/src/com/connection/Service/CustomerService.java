package com.connection.Service;

import java.util.ArrayList;

import com.connection.Dao.CustomerDAO;
import com.connection.Dao.CustomerDAOI;
import com.connection.pojo.Customer;
//import com.nucleus.Controller.ServletController;

   
public class CustomerService implements CustomerI
{
	CustomerDAO customer=new CustomerDAO();
	Customer cus=new Customer();
	//ServletController cont=new ServletController();
	CustomerDAOI check=new CustomerDAO();
	
//########################################### new insert ################################################################################
	
	public void insert (Customer cus)
	{
		CustomerDAO customer=new CustomerDAO(); 
		customer.inputdb(cus);
	}
//########################################### update ################################################################################
	public Customer inputcode(String Customercode)
	{
		CustomerDAO customer=new CustomerDAO(); 
		return customer.inputcode(Customercode);
	}
	public void inputup(Customer cus) 
	{
		CustomerDAO customer=new CustomerDAO(); 
		customer.inputup(cus);
	}
//########################################### delete ################################################################################
	public String inputdelete(String Customercode)
	{
		CustomerDAO customer=new CustomerDAO(); 
		return customer.inputdelete(Customercode);
	}
	
	public Customer inputview(String Custmcode)
	{
		CustomerDAO customer=new CustomerDAO();
		return customer.inputcode(Custmcode);
	}
	public ArrayList<Customer> inputmulti()
	{
		CustomerDAO customer=new CustomerDAO();
		return customer.inputmulti();
	}
}


















