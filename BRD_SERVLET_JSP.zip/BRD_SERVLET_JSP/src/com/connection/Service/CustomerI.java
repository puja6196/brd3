package com.connection.Service;

import java.util.ArrayList;

import com.connection.pojo.Customer;

public interface CustomerI {

	public void insert (Customer cus);
	
	public Customer inputcode(String Customercode);
	
	public void inputup(Customer cus);
	
	public String inputdelete(String Customercode);
	
	public Customer inputview(String Custmcode);
	
	public ArrayList<Customer> inputmulti();

}
