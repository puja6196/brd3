package com.connection.Service;

public interface userServiceI
{
	
	public String checkmethod(String user,String pass);

}
