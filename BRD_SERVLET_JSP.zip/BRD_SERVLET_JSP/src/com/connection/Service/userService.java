package com.connection.Service;

import com.connection.Dao.DAO;
import com.connection.Dao.DAOI;

public class userService implements userServiceI 
{
	DAOI check=new DAO();
	public String checkmethod(String user,String pass) 
	{
		return check.userDao(user,pass);
	}

}
