package com.connection.fact;

import com.connection.ConnectionI;
import com.connection.MySql;
import com.connection.OracleConnection;
import com.connection.SqlServer;

public class Connectionfactory {

	public static com.connection.ConnectionI getConnectionMethod(String str)
	{
		if(str.equalsIgnoreCase("oracle"))
		{
			return new OracleConnection();
		}
		else if(str.equalsIgnoreCase("mysql"))
		{
			return new MySql();
		}
		else if(str.equalsIgnoreCase("sqlserver"))
		{
			return new SqlServer();
		}
		return null;
	}

	public static ConnectionI getConnectionMethod() {
		// TODO Auto-generated method stub
		return null;
	}



}
