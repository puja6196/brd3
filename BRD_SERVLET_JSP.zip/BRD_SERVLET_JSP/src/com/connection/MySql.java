package com.connection;

import java.sql.Connection;

public class MySql implements ConnectionI 
{
	Connection conn=null;
	@Override
	public Connection myConnection() 
	{
		return null;
	}

}