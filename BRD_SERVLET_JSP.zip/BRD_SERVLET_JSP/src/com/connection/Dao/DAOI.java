package com.connection.Dao;



public interface DAOI {

	public String userDao(String user, String pass);

}
