package com.connection.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.connection.ConnectionI;
import com.connection.fact.Connectionfactory;

public class DAO implements DAOI
{
		Connection conn=null;
		ConnectionI c=null;
	
//###################################### USER DAO TO FETCH MEKER OR CHECHKER ###################################################################
	
	public String userDao (String user, String pass)
	{
			c=Connectionfactory.getConnectionMethod("oracle");
			conn=c.myConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		PreparedStatement ps1=null;
		ResultSet rs1=null;
		
		 try 
		 {
			 ps=conn.prepareStatement("select * from Useramitsri where USERNAME=?AND USERPASSWORD=?");
				System.out.println("3");
		   	 ps.setString(1, user);
			 ps.setString(2, pass);
			 rs=ps.executeQuery();
				System.out.println("2");
		if(rs.next())
		{
			ps1=conn.prepareStatement("select Useramitroll.ROLLNAME from Useramitroll,Useramitsri where Useramitsri.ROLLID=Useramitroll.ROLLID and Useramitsri.USERNAME=?");
			ps1.setString(1, user);
			rs1=ps1.executeQuery();
					System.out.println("1");
	    		if(rs1.next())
				{
	    			System.out.println("0");
			    	String role=rs1.getString(1);
					System.out.println(role);
					return role;
						
				}
			} 
		 }
			 catch (SQLException e) 
			 {
				e.printStackTrace();
			 }
		 finally
			{
				try {
					conn.close();
					ps.close();
					rs.close();
					ps1.close();
					rs1.close();
					} 
				catch (SQLException e) 
				{
				
					e.printStackTrace();
				}
			}
		 	return null;
		 }
 	}
	
//########################################## THE END... ##############################################################################################
