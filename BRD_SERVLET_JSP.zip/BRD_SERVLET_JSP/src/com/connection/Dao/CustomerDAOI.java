package com.connection.Dao;

import java.util.ArrayList;

import com.connection.pojo.Customer;

public interface CustomerDAOI 
{
	
	public void inputdb(Customer cus);
	
	public Customer inputcode(String Customercode);
	
	public void inputup(Customer cus);
	
	public String inputdelete(String Customercode);
	
	public Customer inputview(String Custmcode);
	
	public ArrayList<Customer> inputmulti();
	

}
