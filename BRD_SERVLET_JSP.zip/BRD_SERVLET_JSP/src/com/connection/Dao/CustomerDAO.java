package com.connection.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.connection.fact.Connectionfactory;

import com.connection.ConnectionI;
import com.connection.pojo.Customer;

public class CustomerDAO implements CustomerDAOI
{
		int check=0;
		Connection conn=null;
		ConnectionI c=null;
	
		Customer cust=new Customer();
		
//################################################ NEW CUSTOMER ADD METHOD ###################################################################
		
	public void inputdb(Customer cus) 
	{
		c=Connectionfactory.getConnectionMethod("oracle");
		conn=c.myConnection();
		PreparedStatement ps=null;
			try
		{
				ps=conn.prepareStatement("insert into cCustomer values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ");
				ps.setInt(1,cus.getCustomerId());
				ps.setString(2,cus.getCustomerCode());
				System.out.println(cus.getCustomerCode());
				ps.setString(3,cus.getCustomerName());
				ps.setString(4,cus.getCustomerAddress1());
				ps.setString(5,cus.getCustomerAddress2());
				ps.setInt(6,cus.getCustomerPinCode());
				ps.setString(7,cus.geteMailAddress());
				ps.setLong(8,cus.getContactNumber());
				ps.setString(9,cus.getPrimaryContactPerson());
				ps.setString(10,cus.getRecordStatus());
				ps.setString(11,cus.getActiveInactiveFlag());
				ps.setString(12,cus.getCreateDate());
				ps.setString(13,cus.getCreatedBy());
				ps.setString(14,cus.getModifiedDate());
				ps.setString(15,cus.getModifiedBy());
				ps.setString(16,cus.getAuthorizedDate());
				ps.setString(17,cus.getAuthorizedBy());
				ps.executeUpdate();
			
				System.out.println("done");
				conn.commit();
		}
			catch (SQLException e) 
			{
				e.printStackTrace();
			} 
			finally
			{
				try {
					conn.close();
					ps.close();
					
					} 
				catch (SQLException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}
	
//############################################ UPDATE FETCH FROM SQL TABLE ##################################################################
	
		public Customer inputcode(String Customercode)
		{
				c=Connectionfactory.getConnectionMethod("oracle");
				conn=c.myConnection();	
				PreparedStatement ps=null;
				ResultSet rs=null;
			try { 
				System.out.println("in try");
						ps=conn.prepareStatement("select * from cCustomer where CUSTOMER_CODE=?");
						ps.setString(1, Customercode);
						rs=ps.executeQuery();
					if(rs.next())
					{		System.out.println("in if");
							cust.setCustomerId(rs.getInt(1));
							cust.setCustomerCode(rs.getString(2));
							cust.setCustomerName(rs.getString(3));
							cust.setCustomerAddress1(rs.getString(4));
							cust.setCustomerAddress2(rs.getString(5));
							cust.setCustomerPinCode(rs.getInt(6));
							cust.seteMailAddress(rs.getString(7));
							cust.setContactNumber(rs.getLong(8));
							cust.setPrimaryContactPerson(rs.getString(9));
							cust.setRecordStatus(rs.getString(10));
							cust.setActiveInactiveFlag(rs.getString(11));
							cust.setCreateDate(rs.getString(12));
							cust.setCreatedBy(rs.getString(13));
							cust.setModifiedDate(rs.getString(14));
							cust.setModifiedBy(rs.getString(15));
							cust.setAuthorizedDate(rs.getString(16));
							cust.setAuthorizedBy(rs.getString(17));
							System.out.println("done");
							return cust ;
					} 
				}
					catch (SQLException e)
					{
						e.printStackTrace();
					}	
				
					finally
					{
						try {
							conn.close();
							ps.close();
							rs.close();
							} 
						catch (SQLException e) 
						{
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
					}return null;
					
			}
		
		
//##################################################### UPDETE DATA ###########################################################################
		
		public void inputup(Customer cus) 
		{
			c=Connectionfactory.getConnectionMethod("oracle");
			conn=c.myConnection();
			PreparedStatement ps1=null;
			
			try
			{
			ps1=conn.prepareStatement("update cCustomer set CUSTOMER_CODE=?,CUSTOMER_NAME=?,CUSTOMER_ADDRESS1=?,"
						+ "CUSTOMER_ADDRESS2=?,CUSTOMER_PIN_CODE=?,CUSTOMER_EMAIL_ADDERSS=?,CUSTOMER_CONTACT=?,"
			+ "CUSTOMER_PRIMARY_CONTACT=?,CUSTOMER_RECORD_STATUS=?,CUSTOMER_ACTIVE_INACTIVE_FLAG=? where CUSTOMER_CODE=?");
				
						ps1.setString(1,cus.getCustomerCode());
						ps1.setString(2,cus.getCustomerName());
						ps1.setString(3,cus.getCustomerAddress1());	
						ps1.setString(4,cus.getCustomerAddress2());
						ps1.setInt(5,cus.getCustomerPinCode());
						ps1.setString(6,cus.geteMailAddress());
						ps1.setLong(7,cus.getContactNumber());
						ps1.setString(8,cus.getPrimaryContactPerson());
						ps1.setString(9,cus.getRecordStatus());
						ps1.setString(10,cus.getActiveInactiveFlag());
						ps1.setString(11,cus.getCustomerCode());
						System.out.println("ho gaya ji");
					int count=	ps1.executeUpdate();
					System.out.println(count);
						System.out.println("done ji");
						conn.commit();
						System.out.println("commit done");
			}
			catch (SQLException e)
			{
				e.printStackTrace();
			}

			finally
			{
				try {
					conn.close();
					ps1.close();
					} 
				catch (SQLException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
//##################################################### DELETE DATA #############################################################################
		
			public String inputdelete(String Customercode)
			{
				c=Connectionfactory.getConnectionMethod("oracle");
				conn=c.myConnection();
				PreparedStatement ps=null;
				ResultSet rs=null;
				
			try {
				ps=conn.prepareStatement("delete from cCustomer where CUSTOMER_CODE=?");
				ps.setString(1, Customercode);
				rs=ps.executeQuery();
				
				if(rs.next())
					{
						return "det";
					}
				}
					catch (SQLException e)
					{
						e.printStackTrace();
					}
			finally
			{
				try {
					conn.close();
					ps.close();
					rs.close();
					} 
				catch (SQLException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
					return null;
			}
		
//###################################################### VIEW SINGLE DATA BY CODE ##############################################################
			
		public Customer inputview(String Custmcode)
		{
				c=Connectionfactory.getConnectionMethod("oracle");
				conn=c.myConnection();
				PreparedStatement ps2=null;
				ResultSet rs2=null;
				
			try {
					ps2=conn.prepareStatement("select * from cCustomer where CUSTOMER_CODE=?");
					ps2.setString(1, Custmcode);
					rs2=ps2.executeQuery();
				
					if(rs2.next())
					{
					cust.setCustomerId(rs2.getInt(1));
					cust.setCustomerCode(rs2.getString(2));
					cust.setCustomerName(rs2.getString(3));
					cust.setCustomerAddress1(rs2.getString(4));
					cust.setCustomerAddress2(rs2.getString(5));
					cust.setCustomerPinCode(rs2.getInt(6));
					cust.seteMailAddress(rs2.getString(7));
					cust.setContactNumber(rs2.getLong(8));
					cust.setPrimaryContactPerson(rs2.getString(9));
					cust.setRecordStatus(rs2.getString(10));
					cust.setActiveInactiveFlag(rs2.getString(11));
					cust.setCreateDate(rs2.getString(12));
					cust.setCreatedBy(rs2.getString(13));
					cust.setModifiedDate(rs2.getString(14));
					cust.setModifiedBy(rs2.getString(15));
					cust.setAuthorizedDate(rs2.getString(16));
					cust.setAuthorizedBy(rs2.getString(17));
					return cust ;
					} 
				}
					catch (SQLException e)
					{
						e.printStackTrace();
					}
			finally
			{
				try {
					conn.close();
					ps2.close();
					rs2.close();
					} 
				catch (SQLException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
					return null;	
			}
		
//################################################ VIEW MULTIPLE DATA ############################################################################
		
		public ArrayList<Customer> inputmulti()
		{
				ArrayList<Customer> cu = new ArrayList<Customer>();
				
				c=Connectionfactory.getConnectionMethod("oracle");
				conn=c.myConnection();
				PreparedStatement ps3=null;
				ResultSet rs3=null;
				
			try {
				ps3=conn.prepareStatement("select * from cCustomer");
				rs3=ps3.executeQuery();
	
					while(rs3.next())
					{
						Customer cust=new Customer();
						cust.setCustomerId(rs3.getInt(1));
						cust.setCustomerCode(rs3.getString(2));
						cust.setCustomerName(rs3.getString(3));
						cust.setCustomerAddress1(rs3.getString(4));
						cust.setCustomerAddress2(rs3.getString(5));
						cust.setCustomerPinCode(rs3.getInt(6));
						cust.seteMailAddress(rs3.getString(7));
						cust.setContactNumber(rs3.getLong(8));
						cust.setPrimaryContactPerson(rs3.getString(9));
						cust.setRecordStatus(rs3.getString(10));
						cust.setActiveInactiveFlag(rs3.getString(11));
						cust.setCreateDate(rs3.getString(12));
						cust.setCreatedBy(rs3.getString(13));
						cust.setModifiedDate(rs3.getString(14));
						cust.setModifiedBy(rs3.getString(15));
						cust.setAuthorizedDate(rs3.getString(16));
						cust.setAuthorizedBy(rs3.getString(17));
						cu.add(cust) ;
					} 
				}
					catch (SQLException e)
					{
						e.printStackTrace();
					}
			finally
			{
				try {
					conn.close();
					ps3.close();
					rs3.close();
					} 
				catch (SQLException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
					return cu;
			}		
	}
//########################################### THE END... ############################################################################################





