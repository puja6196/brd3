package com.connection;

import java.sql.Connection;


public class SqlServer implements ConnectionI 
{
	Connection conn=null;
	@Override
	public Connection myConnection()
	{
		return null;
	}

}


