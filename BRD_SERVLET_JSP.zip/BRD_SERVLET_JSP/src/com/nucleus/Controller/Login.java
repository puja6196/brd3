package com.nucleus.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.connection.Service.userService;

@WebServlet("/Login")
public class Login extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
    
    public Login() 
    {
        super();
    }
    
//#############################  DO GET METHOD #############################################################################################
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
//##############################  DO POST METHOD ###########################################################################################
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String check;
		userService user=new userService();
		
		response.setContentType("text/html");
		String username=request.getParameter("user");
		String password=request.getParameter("pass");
		
		check=user.checkmethod(username, password);
		
		if(check==null)
		{
			PrintWriter print=response.getWriter();
			print.print("Sorry Wrong Input Please try Again");
			RequestDispatcher r=request.getRequestDispatcher("login.jsp");
			r.include(request, response);
		}
		
		else if(check.equalsIgnoreCase("maker"))
		{	
			HttpSession session=request.getSession(); // SESSION USER FOR MENU PAGE...
			session.setAttribute("user", username);
			
			RequestDispatcher r=request.getRequestDispatcher("MenuFile.jsp");
			r.include(request, response);
		}
		
		else if(check.equalsIgnoreCase("checker"))
		{	
			RequestDispatcher r=request.getRequestDispatcher("checker.jsp");
			r.forward(request, response);
		}
		
	}
	
}
//########################################### THE END... ############################################################################################




