package com.nucleus.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.connection.Dao.CustomerDAO;
import com.connection.Service.CustomerService;
import com.connection.pojo.Customer;

@WebServlet("/ServletController")
public class ServletController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
    
    public ServletController()
    {
        super();
    }
 //#############################  DO GET METHOD #############################################################################################
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
//############################## SESSION #####################################################################################################
		
		HttpSession session=request.getSession(false);
		
//################################################# MENU WORK  ################################################################################	
		
		if(session.getAttribute("user")!=null)
	{
		String action=request.getParameter("action");
		
		if(action.equals("Home"))
		{
			RequestDispatcher r=request.getRequestDispatcher("home.jsp");
			r.forward(request,response);
		}
		if(action.equals("AddNewCustomer"))
		{
			RequestDispatcher r=request.getRequestDispatcher("new.jsp");
			r.forward(request,response);
		}
		else if(action.equals("UpdateDtails"))
		{
			RequestDispatcher r=request.getRequestDispatcher("Newupdate.jsp");
			r.forward(request,response);
		}
		else if(action.equals("DeleteDetails"))
		{
			RequestDispatcher r1=request.getRequestDispatcher("delete.jsp");
			r1.forward(request,response);
		}
		else if(action.equals("viewCustomer"))
		{
			RequestDispatcher r1=request.getRequestDispatcher("view.jsp");
			r1.forward(request,response);
		}
		else if(action.equals("logout"))
		{  
			PrintWriter print=response.getWriter();
			print.print("you are successfuly logged out");
			RequestDispatcher r1=request.getRequestDispatcher("login.jsp");
			r1.include(request,response);
		}
		else
		{
			RequestDispatcher r1=request.getRequestDispatcher("MenuFile.jsp");
			r1.forward(request,response);
		}
	}
//################################### SESSION ELSE  ##########################################################################################
		
		else
		{
			RequestDispatcher r1=request.getRequestDispatcher("login.jsp");
			r1.forward(request,response);
		}
	}

//##################################### POST METHOD ##########################################################################################
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
			CustomerDAO customer=new CustomerDAO(); // DAO OBJECT CREATED
			Customer cus=new Customer();       	// POJO OBJECT CREATED
			CustomerService serv=new CustomerService();
//################################################ NEW CUSTOMER ADD METHOD ###################################################################
			
		if(request.getParameter("SUBMIT")!=null)
		{
			String a=request.getParameter("CustomerId");
			String b=request.getParameter("CustomerCode");
			System.out.println(b);
			String c=request.getParameter("CustomerName");
			String d=request.getParameter("CustomerAddress1");
			String e=request.getParameter("CustomerAddress2");
			String f=request.getParameter("CustomerPincode");
			String g=request.getParameter("eMailAddress");
			String h=request.getParameter("ContactNumber");
			String i=request.getParameter("PrimaryContactPerson");
			String j=request.getParameter("RecordStatus");
			String k=request.getParameter("ActiveInactiveFlag");
			String l=request.getParameter("CreateDate");
			String m=request.getParameter("CreatedBy");
			String n=request.getParameter("ModifiedDate");
			String o=request.getParameter("ModifiedBy");
			String p=request.getParameter("AuthorizedDate");
			String q=request.getParameter("AuthorizedBy");		
		
				cus.setCustomerId(Integer.parseInt(a));
				cus.setCustomerCode(b);
				cus.setCustomerName(c);
				cus.setCustomerAddress1(d);
				cus.setCustomerAddress2(e);
				cus.setCustomerPinCode(Integer.parseInt(f));
				cus.seteMailAddress(g);
				cus.setContactNumber(Long.parseLong(h));
				cus.setPrimaryContactPerson(i);
				cus.setRecordStatus(j);
				cus.setActiveInactiveFlag(k);
				cus.setCreateDate(l);
				cus.setCreatedBy(m);
				cus.setModifiedDate(n);
				cus.setModifiedBy(o);
				cus.setAuthorizedDate(p);
				cus.setAuthorizedBy(q);
				
				serv.insert(cus); // customer service call
		
			//customer.inputdb(cus); // DAO METHOD CALL
		}
//############################################ UPDATE FETCH FROM SQL TABLE ################################################################
		
		if(request.getParameter("getcode")!=null)
		{
					String code=request.getParameter("Code");
					Customer ob=serv.inputcode(code); 
			if(ob!=null) 
			{
					request.setAttribute("cus", ob);
					RequestDispatcher r1=request.getRequestDispatcher("update.jsp");
					r1.include(request,response);
			}
			else
			{
					PrintWriter print=response.getWriter();
					print.print("Wrong Customer Code");
					RequestDispatcher r1=request.getRequestDispatcher("Newupdate.jsp");
					r1.include(request,response);
			}
			
		}
//##################################################### UPDETE DATA #########################################################################
		
		if(request.getParameter("UPDATE")!=null)
		{
					cus.setCustomerId(Integer.parseInt(request.getParameter("CustomerId")));
					cus.setCustomerCode(request.getParameter("CustomerCode"));
					cus.setCustomerName(request.getParameter("CustomerName"));
					cus.setCustomerAddress1(request.getParameter("CustomerAddress1"));
					cus.setCustomerAddress2(request.getParameter("CustomerAddress2"));
					cus.setCustomerPinCode(Integer.parseInt(request.getParameter("CustomerPincode")));
					cus.seteMailAddress(request.getParameter("eMailAddress"));
					cus.setContactNumber(Long.parseLong(request.getParameter("ContactNumber")));
					cus.setPrimaryContactPerson(request.getParameter("PrimaryContactPerson"));
					cus.setRecordStatus(request.getParameter("RecordStatus"));
					cus.setActiveInactiveFlag(request.getParameter("ActiveInactiveFlag"));
					cus.setCreateDate(request.getParameter("CreateDate"));
					cus.setCreatedBy(request.getParameter("CreatedBy"));
					cus.setModifiedDate(request.getParameter("ModifiedDate"));
					cus.setModifiedBy(request.getParameter("ModifiedBy"));
					cus.setAuthorizedDate(request.getParameter("AuthorizedDate"));
					cus.setAuthorizedBy(request.getParameter("AuthorizedBy"));		
			
					serv.inputup(cus);
					//customer.inputup(cus); // DAO METHOD CALL
		}
//##################################################### DELETE DATA ############################################################################
		
		if(request.getParameter("delete")!=null)
		{
					String code=request.getParameter("Code");
					String st=serv.inputdelete(code); 
			if(st!=null)
			{
					PrintWriter print=response.getWriter();
					print.print("successfully deleted");
					RequestDispatcher r1=request.getRequestDispatcher("delete.jsp");
					r1.include(request,response);
			}
			else
			{
					PrintWriter print=response.getWriter();
					print.print("Wrong Customer Code");
					RequestDispatcher r1=request.getRequestDispatcher("delete.jsp");
					r1.include(request,response);
			}
			
		}
	
		
//###################################################### VIEW SINGLE DATA BY CODE ##############################################################
		
		if(request.getParameter("single")!=null)
		{ 
					String st1=request.getParameter("singlecode");
					
					Customer ob = serv.inputview(st1); 
			if(ob!=null) 
			{
					ArrayList<Customer> cu = new ArrayList<Customer>(); // ARRAYLIST USED FOR OBJECT KO ARRAY ME KR K BEJENGE BCOZ WO PAGE ARRAY LETA H
					cu.add(ob);
					request.setAttribute("cus", cu);
					RequestDispatcher r1=request.getRequestDispatcher("multi.jsp");
					r1.include(request,response);
			}
			else
			{
					PrintWriter print=response.getWriter();
					print.print("Wrong Customer Code Please try Again");
					RequestDispatcher r1=request.getRequestDispatcher("view.jsp");
					r1.include(request,response);
			}
		}
//################################################ VIEW MULTIPLE DATA ############################################################################
		
		if(request.getParameter("multiple")!=null)
		{
				ArrayList<Customer> cut = new ArrayList<Customer>(); // ARRAYLIST USED...
				cut=serv.inputmulti();
				request.setAttribute("cus", cut);
				RequestDispatcher r1=request.getRequestDispatcher("multi.jsp");
				r1.include(request,response);
		}
	}
}
	
//########################################### THE END... ############################################################################################




