package com.nucleus.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.book.Book;

@Controller
public class ControllerOne 
{
	@RequestMapping("/link1")
	public ModelAndView handler1()
	{
		return new ModelAndView("success");
	}
	
	@RequestMapping("/BookReg")
	public String handler2(Book book)
	{
		return "BookRegistration";
	}
	
	@RequestMapping("/booksubmit")
	public ModelAndView handler3(Book book)
	{
		return new ModelAndView("success");
	}
}
