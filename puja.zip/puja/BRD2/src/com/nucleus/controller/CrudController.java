package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.nucleus.model.Customer;
import com.nucleus.service.ServiceImpl;
import com.nucleus.service.ServiceInterface;

/**
 * Servlet implementation class CrudController
 */
@WebServlet("/CrudController")
public class CrudController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CrudController() {
        super();

    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    public void setData(Customer customer,HttpServletRequest request, HttpServletResponse response)
    {

    	customer.setCustomerCode(request.getParameter("cCode"));
    	customer.setCustomerName(request.getParameter("cName"));
    	customer.setCustomerAddress1(request.getParameter("add1"));
    	customer.setCustomerAddress2(request.getParameter("add2"));
    	customer.setCustomerPinCode(Long.parseLong(request.getParameter("pin")));
    	customer.setEmailAddress(request.getParameter("email"));
    	customer.setContactNumber(Long.parseLong(request.getParameter("contactNo")));
    	customer.setPrimaryContactPerson(request.getParameter("primaryContact"));
    	customer.setRecordStatus(request.getParameter("recordStatus"));
    	customer.setActiveInactiveFlag(request.getParameter("flag"));

    }
    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String task=request.getParameter("task");
		//ServiceInterface serviceImpl=new ServiceImpl();
		HttpSession session=request.getSession();
		if(session!=null)
		{
			if (session.getAttribute("userId") != null)
			{
				if(task.equals("viewAll"))
				{ System.out.println("welcome to view all");
					request.getRequestDispatcher("viewall.jsp?page=0").forward(request, response); 
					/*
					System.out.println("validate viewall");
					List<Customer> customerList=serviceImpl.viewAllCustomerDAO(pageid,total);
					request.setAttribute("customerList", customerList);
					request.getRequestDispatcher("viewall.jsp").forward(request, response); 
			      */
				}
			}
		}

		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		PrintWriter out=response.getWriter();
		String userId=(String)session.getAttribute("userId");
		Customer customer=new Customer();
		ServiceInterface serviceImpl=new ServiceImpl();

		response.setContentType("text/html");

		if(session!=null)
		{
			if (session.getAttribute("userId") != null)
			{
				out.print("Hello, " + userId + "  Welcome to Insert Page crud<br><br>");
				String submit=request.getParameter("btn");
				System.out.println(request.getParameter("btn"));
				System.out.println("SUBMIT BUTTON VALUE-"+submit);
				////////////////////////////////////////////////
				/////////////////////////////////////////////////////////////	
				if(submit.equals("insert"))
					{
					customer.setCreatedBy((String)session.getAttribute("userId"));
					setData(customer, request, response);
					if(serviceImpl.insertCustomerDAO(customer))
					{
						System.out.println("validate");
					request.setAttribute("message","SUCCESFULLY INSERTED");
					   request.getRequestDispatcher("maker.jsp").forward(request, response); 
					}
					else
					{
						System.out.println("error");
						request.setAttribute("message","INCORRECT DATA INSERTED");
						   request.getRequestDispatcher("insert.jsp").forward(request, response); 
					}
				      
					}else
					////////////////////////////////////////////////
				////////////////////////////////////////////////
				if(submit.equals("delete"))
				{
					
					String CUSTOMER_CODE=(String)request.getParameter("cCode");
					
				if(serviceImpl.deleteCustomerDAO(CUSTOMER_CODE))
				{
					System.out.println("validate delte");
				request.setAttribute("message","SUCCESFULLY DELETED");
				   request.getRequestDispatcher("maker.jsp").forward(request, response); 
				}
				else
				{
					System.out.println("error");
					request.setAttribute("message","Data Not Found");
					   request.getRequestDispatcher("delete.jsp").forward(request, response); 
				}
			      
				}else
				
				////////////////////////////////////////////////
				//////////////////////////////////////////////
				
				if(submit.equals("view"))
				{
					System.out.println("view 1");
					String CUSTOMER_CODE=(String)request.getParameter("cCode");
					
				if(serviceImpl.viewCustomerDAO(CUSTOMER_CODE,customer))
				{
					System.out.println("validate view");

				request.setAttribute("customer", customer);

				   request.getRequestDispatcher("view1.jsp").forward(request, response); 
				}
				else
				{
					System.out.println("error");
					request.setAttribute("message","Data Not Found");
					   request.getRequestDispatcher("view.jsp").forward(request, response); 
				}
			      
				}else
				
				
						if(submit.equals("update"))
						{	customer.setModifiedBy((String)session.getAttribute("userId"));							
							setData(customer, request, response);
							customer.setCustomerCode((String)session.getAttribute("CUSTOMER_CODE"));
							if(serviceImpl.updateCustomerDAO(customer.getCustomerCode(), customer))
							{
								System.out.println("UPADTE SUCCESSFULL");
								request.setAttribute("message","SUCCESFULLY UPDATE");
								request.getRequestDispatcher("maker.jsp").forward(request, response); 
							}
						}else		
				////////////////////////////////////////////////
				//////////////////////////////////////////////
				if(submit.equals(null))
				{
					request.setAttribute("message","please login First");
					   request.getRequestDispatcher("login.jsp").forward(request, response); 
				}
				
				
				
			}
			else
			{
				  
				request.setAttribute("message","please login First");
				   request.getRequestDispatcher("login.jsp").forward(request, response); 
				  
			}
		}
	}

}
