package com.nucleus.connection;



import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class ConnectionSetup
{


	Properties props = new Properties();
	FileInputStream fis = null;
	Connection con;
	public  Connection getConnection()
	{
		
		try {
			String path="C://Users//temp//Desktop//NewWorkspace//StudentProject//db.property";
			fis = new FileInputStream(path);
			props.load(fis);
			String dc=props.getProperty("DC");
			String url=props.getProperty("URL");
			String username=props.getProperty("USERNAME");
			String password=props.getProperty("PASSWORD");
			
	Class.forName(dc);
	con = DriverManager.getConnection(url,username,password);
	}
		catch (ClassNotFoundException e) {
			System.out.println(" Class not Found Exception");
			e.printStackTrace();
		}
	catch (SQLException e) {
		System.out.println("Sql Database error");
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found Exception");
		e.printStackTrace();
	} catch (IOException e) {
System.out.println("Input Output Exception ");
			e.printStackTrace();
		}
		return con;
	
	}

	public void closeConnection()
	{
	try {
		con.close();
	} catch (SQLException e) {
		
		e.printStackTrace();
	}	
	}
	
	

}

