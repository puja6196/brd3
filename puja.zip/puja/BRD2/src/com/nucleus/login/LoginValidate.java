package com.nucleus.login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nucleus.connection.ConnectionSetup;



public class LoginValidate {  
public int validate(String name,String pass,String checkLogin){
	int flag=0;
	//String query="select * from user126 where userid=? and userpassword=?";
	ConnectionSetup connectionSetup = new ConnectionSetup();
	Connection con = connectionSetup.getConnection();
	
	try {
		PreparedStatement pstmt=con.prepareStatement("select * from user126 where userid=? and userpassword=? and checklogin=?");
		pstmt.setString(1,name);  
		pstmt.setString(2,pass); 
		pstmt.setString(3,checkLogin); 
		ResultSet rs=pstmt.executeQuery();
		
		while(rs.next())
		{
			String userid=rs.getString("userid");
			String userpassword=rs.getString("userpassword");
			String roleid=rs.getString("roleid");
			String check=rs.getString("checklogin");
			
			if(userid.equals(name)&&userpassword.equals(pass)&&roleid.equals("role1")&&check.equals(checkLogin))
			{
			 pstmt=con.prepareStatement("update user126 set checklogin=? where userid=? ");
			 pstmt.setString(2,userid);
			 pstmt.setString(1,"true");
			 pstmt.executeQuery();
				flag=1;
				break;
			}
			else
				if(userid.equals(name)&&userpassword.equals(pass)&&roleid.equals("role2")&&check.equals(checkLogin))
				{
					pstmt=con.prepareStatement("update user126 set checklogin=? where userid=? ");
					 pstmt.setString(2,userid);
					 pstmt.setString(1,"true");
					 pstmt.executeQuery();
					flag=2;
					break;
				}
		}
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
	return flag;

}  
}  
