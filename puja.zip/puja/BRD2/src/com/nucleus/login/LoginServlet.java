package com.nucleus.login;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		LoginValidate loginValidate=new LoginValidate();
		String userId=request.getParameter("userId");
		String userPassword=request.getParameter("userPassword");
		response.setContentType("text/html");
		String checkLogin="false";
//		System.out.println(loginValidate.validate(userId, userPassword));
		int flag= loginValidate.validate(userId, userPassword,checkLogin);
		HttpSession session=request.getSession();
		RequestDispatcher rd;
		switch (flag) {
		case 1:session.setAttribute("userId",userId);
		 rd=request.getRequestDispatcher("maker.jsp");  
	      rd.include(request, response); 
			break;
		case 2:session.setAttribute("userId",userId);
	 rd=request.getRequestDispatcher("checker.jsp");  
	      rd.include(request, response); 
			break;
		case 0:out.print("Sorry username or password error");  
	   rd=request.getRequestDispatcher("login.jsp");  
	      rd.include(request, response); 
			break;
		}
			
	}

}
