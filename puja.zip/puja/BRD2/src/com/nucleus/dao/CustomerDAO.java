package com.nucleus.dao;

import java.util.List;

import com.nucleus.model.Customer;

public interface CustomerDAO {
	public boolean insertCustomer(Customer customer);
	public boolean deleteCustomer(String CUSTOMER_CODE);
	public boolean viewCustomer(String CUSTOMER_CODE,Customer customer);

	public List<Customer> viewAllCustomer(int pageid,int total);
	public boolean updateCustomer(String CUSTOMER_CODE,Customer customer);
}
