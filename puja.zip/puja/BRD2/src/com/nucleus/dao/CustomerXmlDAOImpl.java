package com.nucleus.dao;

import java.util.List;

import com.nucleus.model.Customer;

public class CustomerXmlDAOImpl implements CustomerDAO{

	@Override
	public boolean insertCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteCustomer(String CUSTOMER_CODE) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean viewCustomer(String CUSTOMER_CODE, Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Customer> viewAllCustomer(int pageid,int total) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateCustomer(String CUSTOMER_CODE, Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}

}
