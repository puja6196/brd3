package com.nucleus.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.nucleus.connection.ConnectionSetup;
import com.nucleus.model.Customer;
import com.nucleus.validations.CustomerValidations;

public class CustomerDAOImpl implements CustomerDAO{
	ConnectionSetup connectionSetup = new ConnectionSetup();
	Connection con = connectionSetup.getConnection();
	PreparedStatement pstmt=null;
	@Override
	public boolean insertCustomer(Customer customer) {
		System.out.println("Welcome into insert4");
		ConnectionSetup connectionSetup = new ConnectionSetup();
		Connection con = connectionSetup.getConnection();
		long millis =System.currentTimeMillis();
		Date date=new Date(millis);
	
		CustomerValidations customerValidation = new CustomerValidations();
	System.out.println(customerValidation.isPrimary_Key(customer.getCustomerCode(), 10)+" "+customer.getCustomerCode());
		if (customerValidation.isPrimary_Key(customer.getCustomerCode(), 10)
				&& customerValidation.CustomerNameValid(customer.getCustomerName())
				&& customerValidation.isValid_String(customer.getCustomerAddress1(), 100,true)
				&& customerValidation.isValid_String(customer.getCustomerAddress2(), 100)
				&& customerValidation.isvalidCustomer_Pin_Code(customer.getCustomerPinCode(), 6)
				&& customerValidation.isValidEmail_Address(customer.getEmailAddress(), 100)
				&& customerValidation.isValidContact_Number(customer.getContactNumber(), 20)
				&& customerValidation.isValid_String(customer.getPrimaryContactPerson(), 100,true)
				&& customerValidation.isValidRecord_Status(customer.getRecordStatus())
				&& customerValidation.isValidActiveInactive_Flag(customer.getActiveInactiveFlag())
				)
		{
			System.out.println("WELCOME TO INSERT CHECK DATA");
			try {
				pstmt = con.prepareStatement("insert into table100brd values(seq_1000.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
				pstmt.setString(1, customer.getCustomerCode());
				pstmt.setString(2, customer.getCustomerName());
				pstmt.setString(3, customer.getCustomerAddress1());
				pstmt.setString(4, customer.getCustomerAddress2());
				pstmt.setLong(5, customer.getCustomerPinCode());
				pstmt.setString(6, customer.getEmailAddress());
				pstmt.setLong(7, customer.getContactNumber());
				pstmt.setString(8, customer.getPrimaryContactPerson());
				pstmt.setString(9, customer.getRecordStatus());
				pstmt.setString(10, customer.getActiveInactiveFlag());
				pstmt.setDate(11, date);
				pstmt.setString(12, customer.getCreatedBy());
				pstmt.setString(13, null);
				pstmt.setString(14, customer.getModifiedBy());
				pstmt.setString(15, null);
				pstmt.setString(16, customer.getAuthorizedBy());
				pstmt.executeUpdate();
				con.close();
				System.out.println("UPDATE EXECUTED");
				return true;
			} catch (SQLException e) {
				System.out.println("ERROR IN UPDATE QUERY");
				e.printStackTrace();
			}
		}
		return false;
	}

	@Override
	public boolean deleteCustomer(String CUSTOMER_CODE) {
		ConnectionSetup connectionSetup = new ConnectionSetup();
		Connection con = connectionSetup.getConnection();
		String del=null;
		try {
			pstmt=con.prepareStatement("select CUSTOMER_CODE from table100brd where CUSTOMER_CODE=?");
			pstmt.setString(1, CUSTOMER_CODE);
			ResultSet rs=pstmt.executeQuery();  
			if(rs.next())
			del=rs.getString(1);
			
			if(del!=null)
			{
				pstmt=con.prepareStatement("delete from table100brd where CUSTOMER_CODE=?");
				pstmt.setString(1, CUSTOMER_CODE);
				pstmt.executeQuery();
				con.close();
				System.out.println("DELETED");
				return true;
			}
			else
			{
				System.out.println("DATA YOU ENTERED NOT FOUND");
				return false;	
			}

		} catch (SQLException e) {
			System.out.println("ERROR IN DELETE QUERY");
			e.printStackTrace();
		}
		
		return false;
	}
	

	@Override
	public boolean viewCustomer(String customerCode,Customer customer) {
		ConnectionSetup connectionSetup = new ConnectionSetup();
		Connection con = connectionSetup.getConnection();
		//System.out.println("1"+customerCode);
		try {//System.out.println("2"+customerCode);
			pstmt=con.prepareStatement("Select * from table100brd where CUSTOMER_CODE=?");
			pstmt.setString(1, customerCode);
			ResultSet rs=pstmt.executeQuery();  
		//	System.out.println("3"+customerCode);
			while(rs.next())
			{	customer.setCustomerID(rs.getInt(1));
				customer.setCustomerCode(rs.getString(2));
		    	customer.setCustomerName(rs.getString(3));
		    	customer.setCustomerAddress1(rs.getString(4));
		    	customer.setCustomerAddress2(rs.getString(5));
		    	customer.setCustomerPinCode(rs.getLong(6));
		    	customer.setEmailAddress(rs.getString(7));
		    	customer.setContactNumber(rs.getLong(8));
		    	customer.setPrimaryContactPerson(rs.getString(9));
		    	customer.setRecordStatus(rs.getString(10));
		    	customer.setActiveInactiveFlag(rs.getString(11));
		    	customer.setCreateDate(rs.getDate(12));
		    	customer.setCreatedBy(rs.getString(13));
		    	customer.setModifiedDate(rs.getDate(14));
		    	customer.setModifiedBy(rs.getString(15));
		    	customer.setAuthorizedDate(rs.getDate(16));
		    	customer.setAuthorizedBy(rs.getString(17));
		    	System.out.println("VIEWED");
		    	con.close();
		    	return true;
			}
		} catch (SQLException e) {
			System.out.println("ERROR IN VIEW QUERY");
			e.printStackTrace();
		}

		return false;
	}

	
	@Override
	public List<Customer> viewAllCustomer(int start,int total) {
		System.out.println("welcomme 1--"+start+" "+total);
		List<Customer> customerList = new ArrayList<Customer>();
		ConnectionSetup connectionSetup = new ConnectionSetup();
		Connection con = connectionSetup.getConnection();
		try {
			//pstmt=con.prepareStatement("Select * from table100brd");
			//PreparedStatement pstmt=con.prepareStatement("select * from table100brd limit "+(start-1)+","+total);  
			//PreparedStatement pstmt=con.prepareStatement("SELECT * FROM table100brd OFFSET"+(start-1)+"ROWS FETCH NEXT"+total +"ROWS ONLY");  
			PreparedStatement pstmt=con.prepareStatement("SELECT * FROM table100brd OFFSET ? ROWS FETCH NEXT ? ROWS ONLY");  
			pstmt.setInt(1, (start-1));
			pstmt.setInt(2, total);			
			
			ResultSet rs=pstmt.executeQuery();  
			while (rs.next()) 
			{
				Customer customer=new Customer();
				customer.setCustomerID(rs.getInt(1));
				customer.setCustomerCode(rs.getString(2));
		    	customer.setCustomerName(rs.getString(3));
		    	customer.setCustomerAddress1(rs.getString(4));
		    	customer.setCustomerAddress2(rs.getString(5));
		    	customer.setCustomerPinCode(rs.getLong(6));
		    	customer.setEmailAddress(rs.getString(7));
		    	customer.setContactNumber(rs.getLong(8));
		    	customer.setPrimaryContactPerson(rs.getString(9));
		    	customer.setRecordStatus(rs.getString(10));
		    	customer.setActiveInactiveFlag(rs.getString(11));
		    	customer.setCreateDate(rs.getDate(12));
		    	customer.setCreatedBy(rs.getString(13));
		    	customer.setModifiedDate(rs.getDate(14));
		    	customer.setModifiedBy(rs.getString(15));
		    	customer.setAuthorizedDate(rs.getDate(16));
		    	customer.setAuthorizedBy(rs.getString(17));
		    	customerList.add(customer);
			}
			con.close();
			
		} catch (SQLException e) {
			System.out.println("ERROR IN VIEWALL QUERY");
			e.printStackTrace();
		}
		System.out.println("welcomme to final---"+customerList);
		return customerList;
	}

	@Override
	public boolean updateCustomer(String CUSTOMER_CODE, Customer customer) {
		ConnectionSetup connectionSetup = new ConnectionSetup();
		Connection con = connectionSetup.getConnection();
		long millis =System.currentTimeMillis();
		
		Date date=new Date(millis);
		try {
			
			pstmt = con.prepareStatement("update table100brd set CUSTOMER_NAME=?,CUSTOMER_ADDRESS_1=?,CUSTOMER_ADDRESS_2=?,CUSTOMER_PIN_CODE=?,EMAIL_ADDRESS=?,CONTACT_NUMBER=?,ACTIVEINACTIVE_FLAG=?,MODIFIED_DATE=?,MODIFIED_BY=?,RECORD_STATUS=?,PRIMARY_CONTACT_PERSON=? where CUSTOMER_CODE=?");
			pstmt.setString(12,customer.getCustomerCode());
			System.out.println("3");	
		pstmt.setString(1,customer.getCustomerName());
		pstmt.setString(2,customer.getCustomerAddress1());
		pstmt.setString(3,customer.getCustomerAddress2());
		pstmt.setLong(4,customer.getCustomerPinCode());
		pstmt.setString(5,customer.getEmailAddress());
		pstmt.setLong(6,customer.getContactNumber());
		pstmt.setString(7,customer.getActiveInactiveFlag());
		pstmt.setDate(8,date);
		pstmt.setString(9,customer.getModifiedBy());
		pstmt.setString(10,customer.getRecordStatus());
		pstmt.setString(11,customer.getPrimaryContactPerson());

		System.out.println("4");
		
		pstmt.executeQuery();
		con.close();
		System.out.println("5");
		return true;
		} catch (SQLException e) {
			System.out.println("ERROR IN UPDATE QUERY");
			e.printStackTrace();
		}
		return false;
	}

}
