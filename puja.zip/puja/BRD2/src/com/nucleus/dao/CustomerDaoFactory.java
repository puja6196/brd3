package com.nucleus.dao;

public class CustomerDaoFactory {
	public CustomerDAO getCustomerDaoImpl(String implType)
	{
		if(implType.equals("rdms"))
				return new CustomerDAOImpl();
		else if(implType.equals("xml"))
		{
			return new CustomerXmlDAOImpl();
		}
		else return null;
	}

}
