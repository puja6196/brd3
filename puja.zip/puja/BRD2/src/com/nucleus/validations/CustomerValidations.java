package com.nucleus.validations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nucleus.connection.ConnectionSetup;

public class CustomerValidations {

public boolean isValidRecord_Status(String Record_Status)
{
	if(Record_Status!=null)
	{
		
		if(Record_Status.equals("A")||Record_Status.equals("M")||Record_Status.equals("D")||Record_Status.equals("N")||Record_Status.equals("R"))
		{
			
			return true;
		}
	}
	System.out.println("valid status error");
	return false;
}
///////////////////////////////////
///////////////////////////////////
public boolean isValidActiveInactive_Flag(String ActiveInactive_Flag)
{
	if(ActiveInactive_Flag!=null)
	{
		if(ActiveInactive_Flag.equals("A")||ActiveInactive_Flag.equals("I"))
		{
			return true;
		}
	}
	System.out.println("valid flag error");

	return false;
}
//public boolean isValid_String(String string,int size,boolean mandatory)
//{
//	String regex = "[a-zA-Z0-9]+";
//
//	if(mandatory==true)
//	{
//		System.out.println("12");
//	
//		if(string!=null)
//		{
//			System.out.println("13");
//				if(string.length()<=size)
//				{
//					if(string.matches("[a-zA-Z0-9]"))
//				{
//					
//					System.out.println("11");
//					return true;
//					
//				}
//
//				
//			}
//
//			
//		}
//
//		System.out.println("14");
//		return false;
//	}
//	else 
//		if(mandatory==false)
//		{
//		if(string!=null)
//		{
//			if(string.matches("^[a-zA-Z0-9]+$"))
//			{
//				if(string.length()<=size)
//				{
//					return true;
//				}
//				return false;
//			}
//			return false;
//		}
//		}
//	return true;
//	
//}

public boolean isValid_String(String string,int size,boolean mandatory)
{
//	String regex = "[a-zA-Z0-9]+";

	if(mandatory==true)
	{
	
		if(string!=null)
		{
				if(string.length()<=size)
				{
					char[] chars=string.toCharArray();
					for(char xyz:chars)
					{
						if((Character.isLetterOrDigit(xyz)))
						{
							
							return true;
						}
					}
				
				}	
		}
		System.out.println("valid String error "+string);

		return false;
	}
	else 
		if(mandatory==false)
		{
		if(string!=null)
		{
			if(string.length()<=size)
			{
				char[] chars=string.toCharArray();
				for(char xyz:chars)
				{
					if((Character.isLetterOrDigit(xyz)))
					{
						
						return true;
					}
					System.out.println("valid String error "+string);
					return false;
				}
			
			}
		}
		}
	return true;
	
}

///////////////////////////////////////////////////


public boolean isValid_Strin(String string,int size,boolean mandatory)
{
	if(mandatory==true)
	{
	char[] c = string.toCharArray();
	int l = c.length;
	if(l<=size)
		{
			for(char ch :c)
			{
				if(!Character.isLetterOrDigit(ch))
				{
					String c1 = Character.toString(ch);
					if(!c1.equals(" "))
					return false;
				}
			}
			return true;
		}
		return false;
	}return false;
	
	
}
//////////////////////////////////////////
public boolean notNull(String s)
{
	if(s.equals(""))
	{
		return false;
	}
	else
		return true;
}
////////////////////////////////////
public boolean CustomerNameValid(String customerName)
{
	char[] c = customerName.toCharArray();
	
	for(char ch :c)
	{
		if(!Character.isLetterOrDigit(ch))
		{
			String c1 = Character.toString(ch);
			if(!c1.equals(" "))
			return false;
		}
	}
	return true;
			
}

//////////////////////////////////////////////////
public boolean isValid_String(String string,int size)
{
	if(string!=null)
	{
		if(string.length()<=size)
		{
			char[] chars=string.toCharArray();
			for(char xyz:chars)
			{
				if((Character.isLetterOrDigit(xyz)))
				{
					
					return true;
				}
				System.out.println("valid String error "+string);
				return false;
			}
		
		}
	}
	return true;
	
}
///////////////////////////////////
//////////////////////////////
public boolean isValidContact_Number(long string,int size)
{
	
	String mno=String.valueOf(string);
	if(mno!=null)
	{
		if(mno.length()<=size)
		{
			char[] chars=mno.toCharArray();
			for(char xyz:chars)
			{
				if((Character.isDigit(xyz)))
				{
						return true;
					
				}
				System.out.println("valid contact error "+string);
				return false;
			}
		
		}
	}
	return true;
}


//////////////////////////////////

///////////////////////////////////
public boolean isvalidCustomer_Pin_Code(long num,int size)
{

	String mno=String.valueOf(num);
	if(mno!=null)
	{
		if(mno.length()==size)
		{
			char[] chars=mno.toCharArray();
			for(char xyz:chars)
			{
				if((Character.isDigit(xyz)))
				{
					
						return true;
					
				}
				System.out.println("valid customer pin code error "+num);
				return false;
			}
		
		}
	}
	return false;
}





//////////////////////////////////////
public boolean isValidEmail_Address(String email,int size)
{
    String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+
                        "[a-zA-Z0-9_+&*-]+)*@" +
                        "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                        "A-Z]{2,7}$";
                 
    if(email!=null)
    {
    	if(email.length()<=size)
    	{
    	if(String.valueOf(email).matches(emailRegex))
    	{
    		return true;
    	}
    	System.out.println("valid email error "+email);
    	return false;
    	}
    }System.out.println("valid email error "+email);
    return false;
}
//////////////////////////////////////////
//////////////////////////////////////////
public boolean isValidDate(String date)
{
	if(date!=null)
		return true;
	return false;
}
///////////////////////////////////////////

//////////////////////////////////
public boolean isValidFileFormat(String string)
{
	if(string.contains(".txt"))
	{
		return true;
	}
	return false;
}

public boolean isPrimary_Key(String string,int size)
{
	if(string!=null)
	{
		if(string.length()<=size)
		{
			ConnectionSetup connectionSetup=new ConnectionSetup();
			Connection con=connectionSetup.getConnection();
			try{
				PreparedStatement pstmt = con.prepareStatement("select * from table100brd"); 
				ResultSet rs=pstmt.executeQuery();
				while(rs.next())
				{
					String user=rs.getString(2);
					if(user.equals(string))
					{
						System.out.println("unique key constraint");
						return false;
					}
				}return true;
			}catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
	}
	return false;
}
////////////////////////////////////////
//////////////////////////////////////
/*public boolean isPrimary_Key(String string,int size)
{
	String mno=String.valueOf(string);
	if(mno!=null)
	{
		if(mno.length()<=size)
		{
//			char[] chars=mno.toCharArray();
//			for(char xyz:chars)
//			{
//				if((Character.isDigit(xyz)))
//				{
//					String ch=Character.toString(xyz);
//						return true;
//					
//				}
//				
//			}
		return true;
		}
		return false;
	}	System.out.println("valid primarykey error1 "+string);
	return false;
}*/
///////////////////////////////////////
//////////////////////////////////////
//public boolean primaryKey(String customerCode)
//{
//	int count=0;
//	try {
//		ConnectionSetup connectionSetup = new ConnectionSetup();
//		Connection con = connectionSetup.getConnection();
//		PreparedStatement psmt = con.prepareStatement("select * from Student124");
//		ResultSet resultSet = psmt.executeQuery();
//		while(resultSet.next())
//		{
//			if((resultSet.getString(2).equals(customerCode)))
//					{
//				        count++;
//					}
//		}
//	} catch (SQLException e) {
//		e.printStackTrace();
//	}
//		if(count==0)
//		{
//			return true;
//		}
//		else
//			return false;
//}



}
