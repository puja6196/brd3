package com.nucleus.service;

import java.util.List;

import com.nucleus.model.Customer;

public interface ServiceInterface {
	public boolean insertCustomerDAO(Customer customer);
	public boolean deleteCustomerDAO(String CUSTOMER_CODE);
	public boolean viewCustomerDAO(String CUSTOMER_CODE,Customer customer);

	public List<Customer> viewAllCustomerDAO(int pageid,int total);
	public boolean updateCustomerDAO(String CUSTOMER_CODE,Customer customer);
}
