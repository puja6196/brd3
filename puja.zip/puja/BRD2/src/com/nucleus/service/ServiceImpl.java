package com.nucleus.service;

import java.util.List;

import com.nucleus.dao.CustomerDAO;
//import com.nucleus.dao.CustomerDAOImpl;
import com.nucleus.dao.CustomerDaoFactory;
import com.nucleus.model.Customer;

public class ServiceImpl implements ServiceInterface{
//CustomerDAO customerDAOImpl=new CustomerDAOImpl();
CustomerDaoFactory  customerDaoFactory=new CustomerDaoFactory();
CustomerDAO customerDAO=customerDaoFactory.getCustomerDaoImpl("rdms");
	@Override
	public boolean insertCustomerDAO(Customer customer) {
		System.out.println("Welcome into insert3");
		if(customerDAO.insertCustomer(customer))
		{
			return true;
		}
		return false;
	}
	@Override
	public boolean deleteCustomerDAO(String CUSTOMER_CODE) {

		if(customerDAO.deleteCustomer(CUSTOMER_CODE))
		{
			return true;
		}
		return false;
	}
	@Override
	public boolean viewCustomerDAO(String customerCode,Customer customer) {
		if(customerDAO.viewCustomer(customerCode,customer))
		{System.out.println("11"+customerCode);
			return true;
		}
		return false;
	}
	@Override
	public List<Customer> viewAllCustomerDAO(int pageid,int total) {
	//	CustomerDAO customerDAOImpl=new CustomerDAOImpl();
		
		return customerDAO.viewAllCustomer(pageid,total);
	}
	@Override
	public boolean updateCustomerDAO(String CUSTOMER_CODE, Customer customer) {
		if(customerDAO.updateCustomer(CUSTOMER_CODE,customer))
		{
			return true;
		}
		return false;
	}
	
	
	

}
