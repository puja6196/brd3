package com.nucleus.service;

import java.util.List;

import com.nucleus.DAO.CustomerDAO;
import com.nucleus.DAO.DAOFactory;
import com.nucleus.domain.UserInfo;

public class DAOImplService implements DAOService
{

	CustomerDAO customerDAO=DAOFactory.getDAOImplementation("rdbms");	
	public void newUser(UserInfo userInfo)
	{
		customerDAO.newUser(userInfo);
	}
	public List<UserInfo> view(UserInfo userInfo)
	{
		return customerDAO.view(userInfo);
	}
	public void delete(UserInfo userInfo)
	{
		customerDAO.delete(userInfo);
	}
	public List<UserInfo> viewAll()
	{
		return customerDAO.viewAll();
	}
	public 	UserInfo viewUpdate(String usercode)
	{
		 return customerDAO.viewUpdate(usercode);
	}
	public	 void Update (UserInfo userInfo)
	{
		customerDAO.Update (userInfo) ;
	}
	
	
	
	
}



