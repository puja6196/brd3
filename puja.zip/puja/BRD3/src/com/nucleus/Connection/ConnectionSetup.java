package com.nucleus.Connection;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.io.InputStream;
public class ConnectionSetup
{
	Properties properties=new Properties();
    InputStream inputStream;
	Connection con;
	public  Connection getConnection()
	{
		try 
		{
			inputStream=new FileInputStream("C:\\Users\\temp\\Desktop\\Propertiesfile\\property.properties");
			properties.load(inputStream);
			Class.forName(properties.getProperty("driver"));
			con=DriverManager.getConnection(properties.getProperty("url"),properties.getProperty("username"),properties.getProperty("password"));
			System.out.println(con);
		}
		catch (ClassNotFoundException e) 
		{			
			e.printStackTrace();
		}
		catch (SQLException e) 
		{			
			e.printStackTrace();
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		return con; 
	}
	public void closeConnection()
	{
	try
	{
		con.close();
	} 
	catch (SQLException e) 
	{

		e.printStackTrace();
	}	
}
	
	


}
