package com.nucleus.domain;


public class UserInfo 
{  
	private String userCode;
	private String userName;
	private String userAddress1;
	private String userAddress2;
	private String userPinCode;
	private String userEmailAddress;
	private String userContactNo;
	private String primaryContactPerson;
	private String recordStatus;
	private String flag;
	private String createDate;
	private String createdBy;
	private String modifiedDate;
	private String modifiedBy;
	
	public String getCreateDate() {
		return createDate;
	}
	
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String usercode) {
		this.userCode = usercode;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserAddress1() {
		return userAddress1;
	}
	public void setUserAddress1(String userAddress1) {
		this.userAddress1 = userAddress1;
	}
	public String getUserAddress2() {
		return userAddress2;
	}
	public void setUserAddress2(String userAddress2) {
		this.userAddress2 = userAddress2;
	}
	public String getUserPinCode() {
		return userPinCode;
	}
	public void setUserPinCode(String userPinCode) {
		this.userPinCode = userPinCode;
	}
	public String getUserEmailAddress() {
		return userEmailAddress;
	}
	public void setUserEmailAddress(String userEmailAddress) {
		this.userEmailAddress = userEmailAddress;
	}
	public String getPrimaryContactPerson() {
		return primaryContactPerson;
	}
	public void setPrimaryContactPerson(String primaryContactPerson) {
		this.primaryContactPerson = primaryContactPerson;
	}
	public String getRecordStatus() {
		return recordStatus;
	}
	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getUserContactNo() {
		return userContactNo;
	}
	public void setUserContactNo(String userContactNo) {
		this.userContactNo = userContactNo;
	}
	@Override
	public String toString() {
		return "UserInfo [userCode=" + userCode + ", userName=" + userName + ", userAddress1=" + userAddress1
				+ ", userAddress2=" + userAddress2 + ", userPinCode=" + userPinCode + ", userEmailAddress="
				+ userEmailAddress + ", userContactNo=" + userContactNo + ", primaryContactPerson="
				+ primaryContactPerson + ", recordStatus=" + recordStatus + ", flag=" + flag + ", createDate="
				+ createDate + ", createdBy=" + createdBy + ", modifiedDate=" + modifiedDate + ", modifiedBy="
				+ modifiedBy + "]";
	}


}
