package com.nucleus.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;

import com.nucleus.Connection.ConnectionSetup;
import com.nucleus.domain.LoginUser;

public class UserDAOImpl implements UserDAO
{




		ConnectionSetup connectionSetup=new  ConnectionSetup();
	    Connection con= connectionSetup.getConnection();
	    LoginUser loginUser=new LoginUser();
	    
	   
		
		public boolean viewdetails(LoginUser loginUser)
		{
			boolean flag=false;
		  
			try {
				PreparedStatement pstmt=con.prepareStatement("select * from user126 where userid=? and userpassword=?");
				pstmt.setString(1,loginUser.getUserId());  
				pstmt.setString(2,loginUser.getPassword()); 
				
				ResultSet rs=pstmt.executeQuery();
			    
				while(rs.next())
				{
					String userid=rs.getString("userid");
					String userpassword=rs.getString("userpassword");

					if(userid.equals(loginUser.getUserId())&&userpassword.equals(loginUser.getPassword()))
					{
					 pstmt=con.prepareStatement("update user126 set checklogin=? where userid=? ");
					 pstmt.setString(2,userid);
					 pstmt.setString(1,"true");
					 pstmt.executeQuery();
						flag=true;
						break;
					}
				}
				

		         
			}
			catch (SQLException e) 
			{
	         
				e.printStackTrace();
			}
			
			return flag;
			
			
			
			
		
			
	}







		
		}



