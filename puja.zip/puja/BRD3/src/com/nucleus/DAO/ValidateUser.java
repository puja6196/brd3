package com.nucleus.DAO;

public class ValidateUser
{
  public void validate()
  {
	  
	  
	  
  }
  
}
