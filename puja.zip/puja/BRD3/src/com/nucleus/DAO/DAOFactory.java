package com.nucleus.DAO;

public class DAOFactory
{
	public static CustomerDAO getDAOImplementation(String a)
	{
		if(a.equals("rdbms"))
		
		{
		return new CustomerDAOImpl();
		}
		else 
		{
			
	    return new XMLImplementation();
		}
		
		
		
	}
}
