package com.nucleus.DAO;

import com.nucleus.domain.LoginUser;

public interface UserDAO 
{
	
		public boolean viewdetails(LoginUser loginUser);
		

	



	
}
