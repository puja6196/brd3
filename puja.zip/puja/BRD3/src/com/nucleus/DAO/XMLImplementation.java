package com.nucleus.DAO;

import java.util.List;

import com.nucleus.domain.UserInfo;

public class XMLImplementation implements CustomerDAO
{

	@Override
	public void newUser(UserInfo userInfo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<UserInfo> view(UserInfo userInfo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(UserInfo userInfo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<UserInfo> viewAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserInfo viewUpdate(String usercode) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void Update(UserInfo userInfo) {
		// TODO Auto-generated method stub
		
	}

}
